def count_in_list(lst: list, element) -> int:
    """
    Retourne le nombre d'occurrences de `element` dans `lst`.
    """
    return lst.count(element)
